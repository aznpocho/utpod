utpod: Assuming user knows how to use linux, windows or mac

1. Unzip and extract file.

2. Make a directory called utpod on linux machine

3. Move files makefile, song.cpp, song.h, UtPod.cpp, UtPodDriver.cpp, UtPod.h to the utpod directory on linux

4. Optional: if you have a personal UtPodDriver.cpp, then proceed to either not transfer or delete the UtPodDriver.cpp that comes along with the ZIP file and transfer your own UtPodDriver.cpp to linux under the same directory utpod.

5. On linux type the command: make -f makefile

6. To run program, type the command: ./test

7. Read through output.

8. Enjoy!